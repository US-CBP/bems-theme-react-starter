// @flow
import styled from 'styled-components';

const CloneableInputRender = styled.div`
  display: flex;
  align-items: center;
  box-sizing: border-box;
`;

export default CloneableInputRender;
