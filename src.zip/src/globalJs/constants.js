export const RIPPLE_TIME_MS = 225;
