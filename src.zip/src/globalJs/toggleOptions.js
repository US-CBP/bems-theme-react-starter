export const yesNoToggleOptions = [{ label: 'Yes', value: 'Y' }, { label: 'No', value: 'N' }];
export const localZuluToggleOptions = [{ label: 'Local', value: 'LOCAL' }, { label: 'Zulu', value: 'ZULU' }];
export const pendingAcceptRejectToggleOptions = [{ label: 'Pending', value: 'PENDING' }, { label: 'Accept', value: 'ACCEPT' }, { label: 'Reject', value: 'REJECT' }];
