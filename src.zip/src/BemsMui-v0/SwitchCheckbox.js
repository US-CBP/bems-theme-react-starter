import React from 'react';
import Checkbox from '../BemsMui/Checkbox';

const SwitchCheckbox = ({ ...props }) => <Checkbox label="TOMIS Checkbox" {...props} />;

export default SwitchCheckbox;
