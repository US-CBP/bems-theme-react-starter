import IconMenu from 'material-ui/IconMenu';
export default IconMenu;
