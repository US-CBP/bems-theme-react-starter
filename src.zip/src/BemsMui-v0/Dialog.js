import Dialog from 'material-ui/Dialog';
export default Dialog;
