import SvgIcon from 'material-ui/SvgIcon';
export default SvgIcon;
