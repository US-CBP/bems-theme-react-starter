import Paper from 'material-ui/Paper';
export default Paper;
