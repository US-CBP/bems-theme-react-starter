import Subheader from 'material-ui/Subheader';
export default Subheader;
