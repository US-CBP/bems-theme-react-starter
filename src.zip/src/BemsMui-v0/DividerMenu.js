import React from 'react';
import Divider from 'material-ui/Divider';

const DividerMenu = () => <Divider />;

export default DividerMenu;
