import FlatButton from 'material-ui/FlatButton';
export default FlatButton;
