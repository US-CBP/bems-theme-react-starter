import Divider from 'material-ui/Divider';
export default Divider;
