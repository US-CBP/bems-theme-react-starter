import React from 'react';
import IntegrationAutosuggest from './IntegrationAutosuggest';

const DemoAutocomplete = () => {
    return (
        <div>
            <br />
            <IntegrationAutosuggest />
        </div>
    );
};

export default DemoAutocomplete;
