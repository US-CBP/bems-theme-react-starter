import React from 'react';
import UndockedDrawer from './UndockedDrawer';

const DemoDrawers = () => {
    return (
        <div>
            <br />
            <UndockedDrawer />
        </div>
    );
};

export default DemoDrawers;
