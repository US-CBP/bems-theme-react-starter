import React from 'react';
import Chips from './Chips';
import ChipsArray from './ChipsArray';

const DemoChips = () => {
    return (
        <div>
            <br />
            <Chips />
            <br /> <br />
            <ChipsArray />
        </div>
    );
};

export default DemoChips;
