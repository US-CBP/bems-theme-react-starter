import React from 'react';
import SimpleBadge from './SimpleBadge';

const DemoBadges = () => {
    return (
        <div>
            <br />
            <SimpleBadge />
        </div>
    );
};

export default DemoBadges;
