import React from 'react';
import TomisTextFieldSingleLine from 'TomisApp/TomisTextFieldSingleLine';

const Search = props => <TomisTextFieldSingleLine floatingLabelText="Search" hintText="Search" />;
export default Search;
