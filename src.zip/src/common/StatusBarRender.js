import React, { Component } from 'react';
import PropTypes from 'prop-types';

class StatusBarRender extends Component {
  constructor(props) {
    super(props);
  }
  render() {
    return <div>Status Bar with Lots of Display Stuff</div>;
  }
}

export default StatusBarRender;
